# AutoOrder Secure Starter — fondasi untuk proyek Supabase baru

**Status: starter keamanan, belum tersertifikasi dan belum boleh dipakai sebagai klaim “100% aman”.** Paket ini sengaja tidak memakai database bersama `ao_state`, tidak menyertakan kunci rahasia, dan tidak mengaktifkan unggah file. Paket web yang disediakan adalah fondasi buyer untuk autentikasi, katalog, membuat order, dan melihat riwayat. Ini belum menggantikan seluruh UI lama atau semua fitur AutoOrder.

## Isi paket

- `web/`: UI ringan, login/daftar Supabase Auth, katalog, buat order melalui fungsi database yang mengambil harga dari tabel, riwayat order. Input ditampilkan dengan `textContent`, bukan HTML mentah.
- `supabase/migrations/202610150001_initial_secure_schema.sql`: tabel multi-workspace, RLS pada semua tabel pelanggan, helper membership, create-order yang memvalidasi role/harga, batas status order.
- `supabase/functions/join-store/`: Edge Function yang memasukkan user terautentikasi sebagai buyer ke workspace yang dikonfigurasi di server; role tidak dapat dipilih dari browser.
- `netlify.toml`: header keamanan contoh; wajib ganti domain proyek Supabase.
- `.env.example`: hanya nama variabel server, tanpa nilai rahasia.

## Yang belum ada / belum boleh dianggap selesai

- Tidak ada jaminan 100% keamanan. Belum ada audit pihak ketiga, penetration test, pemulihan bencana yang diuji, atau validasi produksi.
- Belum mengintegrasikan semua halaman lama: panel seller lengkap, verifikasi pembayaran QRIS otomatis, live chat UI, klaim garansi UI, loyalty/gacha UI, serta workflow dukungan.
- Belum ada payment gateway atau callback pembayaran tepercaya. Status order bukan bukti pembayaran; jangan tandai lunas hanya karena tangkapan layar.
- Belum ada unggah lampiran. Jangan menyalakan upload/storage sampai desain akses privat, batas ukuran/jenis, scanning, retensi, dan izin berbagi selesai.
- Belum ada sinkronisasi/migrasi data lama. Jangan impor `localStorage` atau row `ao_state` lama mentah-mentah.
- SQL migration belum dijalankan atau diuji terhadap proyek Anda. Harus diuji di staging terlebih dahulu.

## 0. Rahasia VirusTotal yang dikirim di chat

Kunci API VirusTotal yang dikirim di percakapan harus dianggap **terekspos/terkompromi**. Cabut/revoke dan buat kunci baru di akun VirusTotal Anda. Jangan masukkan kunci baru ke HTML, JavaScript, repositori Git, atau chat. Paket ini sengaja tidak menyimpan atau menggunakan kunci tersebut. Jika kelak dibutuhkan, simpan hanya sebagai secret server-side dan pahami bahwa mengirim file/hash ke pihak ketiga dapat menimbulkan konsekuensi privasi.

## 1. Buat proyek Supabase baru

1. Buat proyek baru di Supabase dengan organisasi dan billing yang benar. Gunakan kata sandi database unik, panjang, dan simpan di password manager.
2. Pilih region sesuai kebutuhan hukum/latensi dan catat pemilik proyek. Aktifkan MFA untuk seluruh akun administrator.
3. Jangan menghubungkan proyek lama dan jangan menyalin row `ao_state` ke proyek baru.
4. Di Authentication, aktifkan verifikasi email, atur URL situs/redirect yang tepat, konfigurasi SMTP produksi, dan aktifkan perlindungan kata sandi bocor jika tersedia. Atur rate limits/CAPTCHA sesuai risiko.
5. Simpan URL proyek dan publishable/anon key untuk frontend. **Jangan pernah memakai `service_role` key sebagai anon key.**

## 2. Terapkan database

Gunakan Supabase CLI yang sudah terpasang, login, dan tautkan proyek baru:

```sh
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
```

Pastikan file migration ini berada di folder `supabase/migrations/` pada repo yang ditautkan. Alternatif: tinjau lalu jalankan isi migration melalui SQL Editor di proyek baru. Jangan menjalankan di proyek berisi data produksi sebelum staging dan backup.

## 3. Bootstrap owner/workspace secara manual

1. Buat akun owner di Authentication → Users. Selesaikan verifikasi email dan MFA administrator.
2. Salin UUID user owner dari dashboard. Jalankan SQL berikut di SQL Editor dengan mengganti placeholder UUID. Simpan UUID workspace yang dikembalikan.

```sql
insert into public.workspaces (name, created_by)
values ('AutoOrder', 'REPLACE_WITH_OWNER_AUTH_USER_UUID'::uuid)
returning id;

-- Jalankan perintah berikut dengan UUID workspace hasil query di atas:
insert into public.workspace_members (workspace_id, user_id, role)
values ('REPLACE_WITH_WORKSPACE_UUID'::uuid,
        'REPLACE_WITH_OWNER_AUTH_USER_UUID'::uuid,
        'owner');
```

3. Jangan membuat endpoint publik untuk mengubah role. Tambah seller/support secara manual atau lewat fungsi admin yang memverifikasi owner; jangan menerima `role` dari request browser.
4. Setelah masuk menggunakan akun owner atau seller, kelola produk dari panel **Kelola produk** di aplikasi: tambah produk, edit nama/deskripsi/harga, aktifkan/nonaktifkan, dan muat ulang katalog. Perubahan disimpan ke Supabase sehingga tidak perlu mengubah atau deploy ulang `index.html`. Hanya owner yang dapat menghapus produk; seller dapat menonaktifkan produk.
5. Untuk memberi akses seller kepada akun lain, admin harus menambahkan membership role `seller` secara tepercaya di `workspace_members` (jangan sediakan pilihan role publik di form daftar). Contoh SQL admin untuk akun yang sudah diverifikasi:

   ```sql
   insert into public.workspace_members (workspace_id, user_id, role)
   values ('WORKSPACE_UUID', 'AUTH_USER_UUID', 'seller')
   on conflict (workspace_id, user_id) do update set role = excluded.role;
   ```

   Ganti kedua placeholder dengan UUID yang benar dan jalankan hanya oleh administrator tepercaya. Jangan memberi role owner kepada akun seller biasa.

## 4. Konfigurasikan Edge Function

Ganti nilai server dengan milik proyek baru. Jangan commit nilai ini ke Git.

```sh
supabase secrets set ALLOWED_ORIGIN=https://YOUR-PRODUCTION-DOMAIN.example
supabase secrets set AUTOORDER_WORKSPACE_ID=YOUR_WORKSPACE_UUID
supabase functions deploy join-store
```

Runtime Edge Functions Supabase menyediakan variabel koneksi standar. Pastikan `SUPABASE_SERVICE_ROLE_KEY` hanya digunakan di runtime server. Jangan pernah menaruhnya dalam file web.

## 5. Konfigurasikan frontend

Edit `web/config.js`:

```js
export const SUPABASE_URL = 'https://YOUR_PROJECT_REF.supabase.co';
export const SUPABASE_ANON_KEY = 'YOUR_PUBLISHABLE_OR_ANON_KEY';
```

Kunci publishable/anon memang dapat terlihat di browser; keamanan bergantung pada RLS dan fungsi server, bukan menyembunyikan key tersebut. Pastikan `ALLOWED_ORIGIN` dan redirect URL cocok dengan domain deployment. Di `netlify.toml`, ganti `YOUR_PROJECT_REF` pada `connect-src`. Jangan mengaktifkan `unsafe-inline` pada CSP tanpa penilaian keamanan.

Deploy folder `web/` ke hosting HTTPS. Jika memakai hosting lain, salin header dari `netlify.toml` dan sesuaikan dengan kebijakan hosting. Uji Console dan Network browser: tidak boleh ada service role key, VT key, password, atau data pelanggan yang tidak dibutuhkan.

## 6. Uji wajib sebelum pelanggan asli

Lakukan di staging dengan dua akun buyer terpisah, satu seller, dan satu owner:

- [ ] Pengunjung tanpa login tidak dapat membaca profil, membership, order, chat, garansi, atau loyalty.
- [ ] Buyer A tidak dapat membaca/mengubah order Buyer B meskipun menebak UUID.
- [ ] Buyer tidak dapat memasukkan membership, menaikkan role sendiri, mengubah harga, mengubah buyer_id, atau mengubah status order lewat REST API.
- [ ] Buyer hanya dapat membuat order untuk produk aktif yang diizinkan; harga/total diambil server/database, bukan dari input browser.
- [ ] Retry request dengan idempotency key sama tidak membuat order duplikat.
- [ ] Seller tidak dapat membaca workspace lain; seller hanya mengubah status order di workspace miliknya.
- [ ] Periksa semua tabel di Database → Policies: RLS aktif dan policy sesuai kebutuhan.
- [ ] Uji alur email verification, reset password resmi Supabase, sign out, sesi kedaluwarsa, rate limit, dan akun yang dinonaktifkan.
- [ ] Uji XSS pada nama produk/deskripsi/pesan. Semua output harus diperlakukan sebagai teks, tidak dieksekusi sebagai HTML.
- [ ] Pastikan log tidak mencatat kata sandi, OTP, token, API key, isi dokumen, atau data pribadi berlebihan.
- [ ] Aktifkan backup/PITR sesuai paket, uji pemulihan ke proyek terpisah, dan dokumentasikan RPO/RTO.
- [ ] Jalankan pemeriksaan dependency, static analysis, dan penetration test independen; perbaiki semua temuan kritis/tinggi.

## 7. Data lama dan migrasi

Jangan impor JSON `ao_state` atau localStorage secara langsung. Buat skrip migrasi terpisah yang memetakan dan memvalidasi setiap entitas, menghapus kata sandi/OTP/token yang tersimpan, menautkan pengguna ke UUID Supabase Auth yang sudah diverifikasi, dan menghasilkan laporan jumlah record sebelum/sesudah. Backup data lama terenkripsi, batasi akses, tetapkan retensi, lalu hapus backup sementara dengan prosedur yang disetujui.

## 8. Pembayaran, file, dan data pribadi

- Status `menunggu_verifikasi` hanya berarti perlu pemeriksaan. Integrasikan payment provider melalui callback server yang diverifikasi signature-nya; jangan mengandalkan screenshot.
- Tidak ada storage/upload pada starter ini. Jika dibutuhkan, buat bucket privat, RLS Storage, URL bertanda tangan berumur pendek, validasi MIME berdasarkan isi file, batas ukuran, nama file acak, dan pemindaian server-side. Jangan kirim dokumen pribadi ke VirusTotal tanpa penilaian privasi dan persetujuan yang sesuai.
- Kumpulkan data minimum, tampilkan kebijakan privasi, tujuan penggunaan, masa retensi, kontak penghapusan/koreksi, dan proses insiden sesuai hukum yang berlaku.
- Jangan menyimpan kata sandi pelanggan dalam tabel aplikasi. Auth Supabase menangani kredensial.

## 9. Operasional keamanan

- MFA wajib untuk pemilik Supabase, hosting, domain, email, dan akun repositori.
- Pisahkan proyek dev/staging/production; batasi anggota dan hak akses minimum.
- Aktifkan alert untuk login admin, lonjakan error, perubahan konfigurasi, dan penggunaan kuota; tinjau log berkala.
- Rotasi rahasia saat ada paparan atau perubahan personel. Siapkan prosedur cabut sesi, blokir akun, pemulihan backup, komunikasi insiden, dan pelaporan sesuai kewajiban.
- Jalankan pembaruan dependency dan audit berkala. Jangan pernah menjanjikan “tidak ada celah sekecil apa pun”.

## 10. Batas tanggung jawab teknis

Paket ini memberikan baseline yang lebih baik daripada autentikasi buatan sendiri dan satu row JSON bersama, tetapi **bukan sertifikasi keamanan**. Sebelum menerima data pribadi nyata, minta review engineer yang memahami Supabase/Postgres RLS, pengujian isolasi tenant, serta review hukum/privasi yang sesuai. Jangan gunakan dengan pelanggan asli sampai semua checklist di atas lulus.
